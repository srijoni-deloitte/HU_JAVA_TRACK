package com.deloitte.entity;

import com.deloitte.entity.f1_name;
import org.springframework.stereotype.Component;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Component
@Entity

public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private f1_name name;
    private String email;
    private String username;
    private String password;
    private String companyname;

    public User() {
        super();


    }

    public f1_name getName() {
        return name;
    }

    public void setName(f1_name name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUsername() {
        return username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPassword() {
        return password;
    }

    public void setCompanyName(String companyname) {
        this.companyname = companyname;

    }
    public String getCompanyname(){
        return companyname;
    }


}


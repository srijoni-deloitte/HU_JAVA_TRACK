package com.deloitte.login.service;

import com.deloitte.login.entity.User;

import java.util.List;

public interface UserService {
    User createUser(User cust);

    User updateUser(User cust);

    //Customer getCustomerByPan(String panNo);
    User getUserById(int id);

    User getUserByEmail(String email);

    User getUserByUsername(String username);

    List<User> getAllUser();


}
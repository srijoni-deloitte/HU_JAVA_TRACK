package com.deloitte.login.controller;

import com.deloitte.login.entity.User;
import com.deloitte.login.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class signupController {
    @Autowired
    private UserService userService;
    @RequestMapping("signup")
    public String update(@RequestParam String username,@RequestParam String password,@RequestParam String email,@RequestParam String name,@RequestParam String companyname,@RequestParam double salary) {
        User new_user= new User();
        new_user.setEmail(email);
        new_user.setCompanyName(companyname);
        new_user.setName(name);
        new_user.setPassword(password);
        new_user.setUsername(username);
        new_user.setSalary(salary);
        userService.createUser(new_user);
        return "successful_signup";
    }
    
}
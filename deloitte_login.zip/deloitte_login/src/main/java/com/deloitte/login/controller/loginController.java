package com.deloitte.login.controller;

import com.deloitte.login.entity.User;
import com.deloitte.login.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class loginController {
    @Autowired
    private UserService userService;
    @RequestMapping(value = "/login", method = RequestMethod.GET)
    public String login() {
        System.out.println("trying login controller12346");
        return "login";
    }
    @RequestMapping("login_verify")
    public ModelAndView check_login(@RequestParam String username,@RequestParam String password){
        ModelAndView mv=new ModelAndView();
        User new_user= userService.getUserByUsername(username);
        String pass=new_user.getPassword();
        if (pass.equals(password)){
            mv.addObject("sign in as newuser", new_user.getName());
            mv.setViewName("successfull-login");
            return mv;
        }
        else{
            mv.addObject("sign_in failed as",new_user.getName());
            mv.setViewName("unsuccessfull-login");
            return mv;
        }

    }
}

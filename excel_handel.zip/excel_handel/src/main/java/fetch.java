import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

public class fetch {


    public static void main(String[] args) throws Exception {  

    FileInputStream fileIn = new FileInputStream("demo.xlsx");

    POIFSFileSystem fs = new POIFSFileSystem(fileIn); 
    HSSFWorkbook filename = new HSSFWorkbook(fs);

    HSSFSheet sheet = filename.getSheetAt(0);


    String columnWanted = "S.No.";
    Integer columnNo = null;

    List<Cell> cells = new ArrayList<Cell>();

    Row firstRow = sheet.getRow(0);

    for(Cell cell:firstRow){
        if (cell.getStringCellValue().equals(columnWanted)){
            columnNo = cell.getColumnIndex();
        }
    }


    if (columnNo != null){
    for (Row row : sheet) {
       Cell c = row.getCell(columnNo);
       if (c == null || c.getCellType() == null) {

       } else {
          cells.add(c);
       }
    }
    }else{
        System.out.println("could not find column " + columnWanted + " in first row of " + fileIn.toString());
    }
    System.out.println(cells);
    List actual_cell = cells.subList(1, cells.size());
    List res = new ArrayList();

    for(int i=0; i<actual_cell.size();i++) {
    	res.add(Integer.parseInt(actual_cell.get(i).toString()));
    }
    System.out.println(res);
    Collections.sort(res);
    System.out.println("sd");
    List sorted_cells = res.subList(0, 5);
    System.out.println("cells with rank 1-5");
    
    System.out.println(sorted_cells);
    
    for ( int i=0; i<sorted_cells.size(); i++ ) {
    	System.out.println("row "+sorted_cells.get(i).toString());
    	for (int j=0; j<5;j++) {
    		System.out.print(sheet.getRow(Integer.parseInt(sorted_cells.get(i).toString())).getCell(j));
    	}
    	System.out.println();
    	
    }
     }

    }
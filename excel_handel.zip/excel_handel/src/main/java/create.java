
import  java.io.*;  
import  org.apache.poi.hssf.usermodel.HSSFSheet;  
import  org.apache.poi.hssf.usermodel.HSSFWorkbook;  
import  org.apache.poi.hssf.usermodel.HSSFRow;  
public class create 
{  
public static void main(String[]args)   
{  
try   
{  
//declare file name to be create   
String filename = "demo.xlsx";  
//creating an instance of HSSFWorkbook class  
HSSFWorkbook workbook = new HSSFWorkbook();  
//invoking creatSheet() method and passing the name of the sheet to be created   
HSSFSheet sheet = workbook.createSheet("January");   
//creating the 0th row using the createRow() method  
HSSFRow rowhead = sheet.createRow((short)0);  
//creating cell by using the createCell() method and setting the values to the cell by using the setCellValue() method  
rowhead.createCell(0).setCellValue("S.No.");  
rowhead.createCell(1).setCellValue("Customer Name");  
rowhead.createCell(2).setCellValue("Account Number");  
rowhead.createCell(3).setCellValue("e-mail");  
rowhead.createCell(4).setCellValue("Balance");  
//creating the 1st row  
HSSFRow row = sheet.createRow((short)1);  
//inserting data in the first row  
row.createCell(0).setCellValue("1");  
row.createCell(1).setCellValue("John William");  
row.createCell(2).setCellValue("9999999");  
row.createCell(3).setCellValue("william.john@gmail.com");  
row.createCell(4).setCellValue("700000.00");  
//creating the 2nd row  
HSSFRow row1 = sheet.createRow((short)2);  
//inserting data in the second row  
row1.createCell(0).setCellValue("2");  
row1.createCell(1).setCellValue("Mathew Parker");  
row1.createCell(2).setCellValue("22222222");  
row1.createCell(3).setCellValue("parker.mathew@gmail.com");  
row1.createCell(4).setCellValue("200000.00");  

HSSFRow row2 = sheet.createRow((short)3);  
 
row2.createCell(0).setCellValue("3");  
row2.createCell(1).setCellValue("srijoni");  
row2.createCell(2).setCellValue("22222222");  
row2.createCell(3).setCellValue("sri.mathew@gmail.com");  
row2.createCell(4).setCellValue("200000.00"); 

HSSFRow row3 = sheet.createRow((short)4);  

row3.createCell(0).setCellValue("6");  
row3.createCell(1).setCellValue("kuhu");  
row3.createCell(2).setCellValue("22222222");  
row3.createCell(3).setCellValue("kuhu.mathew@gmail.com");  
row3.createCell(4).setCellValue("200000.00"); 

HSSFRow row4 = sheet.createRow((short)5);  

row4.createCell(0).setCellValue("5");  
row4.createCell(1).setCellValue("kugfnhgf");  
row4.createCell(2).setCellValue("22222222");  
row4.createCell(3).setCellValue("kuhu.mhjhgjathew@gmail.com");  
row4.createCell(4).setCellValue("200000.00"); 

HSSFRow row5 = sheet.createRow((short)6);  

row5.createCell(0).setCellValue("4");  
row5.createCell(1).setCellValue("kdfbugfnhgfnhgf");  
row5.createCell(2).setCellValue("22222222");  
row5.createCell(3).setCellValue("kuhufgng.mhjhgjathew@gmail.com");  
row5.createCell(4).setCellValue("200000.00"); 

FileOutputStream fileOut = new FileOutputStream(filename);  
workbook.write(fileOut);  
//closing the Stream  
fileOut.close();  
//closing the workbook  
workbook.close();  
//prints the message on the console  
System.out.println("Excel file has been generated successfully.");  
}   
catch (Exception e)   
{  
e.printStackTrace();  
}  
}  
}  

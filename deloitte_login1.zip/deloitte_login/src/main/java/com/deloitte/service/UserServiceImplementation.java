package com.deloitte.service;

import com.deloitte.entity.User;
import com.deloitte.repo.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImplementation implements UserService {

    @Autowired
    private UserRepository UserRepo;


    
    @Override
    public User createUser(User cust) {
        return UserRepo.save(cust);
    }

    @Override
    public User updateUser(User cust) {
        return UserRepo.save(cust);
    }

    @Override
    public User getUserById(int id) {
        return UserRepo.findById(id).get();
    }

    @Override
    public User getUserByEmail(String email) {
        return UserRepo.findByEmail(email);
    }

    @Override
    public User getUserByUsername(String username) {
        return UserRepo.findByUsername(username);
    }

    @Override
    public List<User> getAllUser() {
        return UserRepo.findAll();
    }
}

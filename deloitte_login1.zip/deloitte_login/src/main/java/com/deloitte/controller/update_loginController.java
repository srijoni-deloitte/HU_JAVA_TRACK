package com.deloitte.controller;

import com.deloitte.entity.User;
import com.deloitte.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class update_loginController {
    @Autowired
    private UserService userService;
    @RequestMapping("update_login")
    public String update(@RequestParam String username,@RequestParam String password,@RequestParam String email,@RequestParam String name,@RequestParam String companyname,@RequestParam double salary) {
        User new_user= userService.getUserByUsername(username);
        new_user.setEmail(email);
        new_user.setCompanyName(companyname);
        new_user.setName(name);
        new_user.setPassword(password);
        new_user.setSalary(salary);
        return "successful_update";
    }
    
}

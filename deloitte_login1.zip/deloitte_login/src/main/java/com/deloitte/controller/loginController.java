package com.deloitte.controller;

import com.deloitte.entity.User;
import com.deloitte.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class loginController {
    @Autowired
    private UserService userService;
    @RequestMapping("login")
    public String login() {
        System.out.println("trying login controller123");
        return "login";
    }
    @RequestMapping("login_verify")
    public ModelAndView check_login(@RequestParam String username,@RequestParam String password){
        ModelAndView mv=new ModelAndView();
        User new_user= userService.getUserByUsername(username);
        String pass=new_user.getPassword();
        if (pass.equals(password)){
            mv.addObject("sign in as newuser", new_user.getName());
            mv.setViewName("successfull-login");
            return mv;
        }
        else{
            mv.addObject("sign_in failed as",new_user.getName());
            mv.setViewName("unsuccessfull-login");
            return mv;
        }

    }
}

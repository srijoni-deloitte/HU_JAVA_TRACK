

class CheckPasswordException extends Exception {
  
    int passwordConditionViolated = 0;
  
    public CheckPasswordException(int conditionViolated)
    {
        super("Invalid Password: ");
        passwordConditionViolated = conditionViolated;
    }
  
    public String printMessage()
    {

        switch (passwordConditionViolated) {

        case 1:
            return ("Password length must be"
                    + " between 5 to 10 characters");

        case 2:
            return ("Password must not"
                    + " have any space");

        case 3:
            return ("Password must have"
                    + " at least one digit(0-9)");

        case 4:
            return ("Password must have at "
                    + "least one special character");

        case 5:
            return ("Password must have at"
                    + " least one uppercase letter(A-Z)");

        case 6:
            return ("Password must have at"
                    + " least one lowercase letter(a-z)");
        }
  
        return ("");
    }
}
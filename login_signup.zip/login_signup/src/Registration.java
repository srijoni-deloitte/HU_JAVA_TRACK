public class Registration {


        public static void main(String[] args)
                throws Exception
        {
            MyFrame f = new MyFrame();
        }

}
